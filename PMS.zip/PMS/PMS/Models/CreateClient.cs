﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMS.Models
{
    public class CreateClient
    {
        public string client_id { get; set; }
        public string client_name { get; set; }
        public string client_website { get; set; }
        public string client_contactnumber { get; set; }
        public string client_address1 { get; set; }
        public string client_address2 { get; set; }
        public string clientcity { get; set; }
        public string clientstate { get; set; }
        public string clientzip { get; set; }
        public string clientcountry { get; set; }
        public string created_by { get; set; }
        public string keyword { get; set; }
        public string ClientContactName { get; set; }
        public string ContactPersonTitle { get; set; }
        public string ClientContactEmail { get; set; }
       // public string Type { get; set; }
        public string clientcontact_address1 { get; set; }
        public string clientcontact_address2 { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string zip { get; set; }
        public string country { get; set; }
        public string created_date { get; set; }

        //public string clientBankName { get; set; }
        //public string clientBankAccountNumber { get; set; }
        //public string clientAccountName { get; set; }
        //public string clientAccountIFSC { get; set; }
        //public string clientBankBranch { get; set; }
    }
}
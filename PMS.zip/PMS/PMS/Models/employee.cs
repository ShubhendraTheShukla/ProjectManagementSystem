﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PMS.Models
{
    public class employee
    {
        public int empId { get; set; }
        public int empEmail { get; set; }
        public SelectList DropDownList { get; set; }
    }
}
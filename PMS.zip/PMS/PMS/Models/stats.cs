﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMS.Models
{
    public class stats
    {
        public string clientCount { get; set; }
        public string projectCount { get; set; }
        public string mileCount { get; set; }
        public List<projectStats> proj { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
namespace PMS.Models
{
    public class MyListTable
    {
        public int empId { get; set; }
        public string empEmail { get; set; }
    }
}
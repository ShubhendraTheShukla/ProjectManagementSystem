﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PMS.Models;

namespace PMS.Models
{
    public class viewEmployees
    {
        public int? empId { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string startdate { get; set; }
        public string projectcode { get; set; }
        public string enddate { get; set; }
        public string empEmail { get; set; }
        //public string keyword { get; set; }
        public List<MyListTable> elist { get; set; }
    }
}
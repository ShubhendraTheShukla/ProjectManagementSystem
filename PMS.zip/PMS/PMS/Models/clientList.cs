﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMS.Models
{
    public class clientList
    {
        public string client_name { get; set; }
    }
}
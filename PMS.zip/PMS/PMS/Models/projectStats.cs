﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMS.Models
{
    public class projectStats
    {
        public string categoryname { get; set; }
        public string counts { get; set; }
    }
}
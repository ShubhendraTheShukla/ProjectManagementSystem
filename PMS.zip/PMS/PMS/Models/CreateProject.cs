﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMS.Models
{
    public class CreateProject
    {
        public string client_id { get; set; }
        public string client_name { get; set; }
        public string project_id { get; set; }
        public string project_name { get; set; }
        public string sow_value { get; set; }
        public string start_date { get; set; }
        public string completion_date { get; set; }
        public List<clientList> clients { get; set; }
        public string keyword { get; set; }

    }
}
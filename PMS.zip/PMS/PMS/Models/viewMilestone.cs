﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMS.Models
{
    public class viewMilestone
    {
        public string milestone_id { get; set; }
        public string milestone_date { get; set; }
        public string sow_value { get; set; }
        public string project_id { get; set; }

    }
}
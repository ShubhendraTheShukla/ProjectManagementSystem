﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMS.Models
{
    public class forgotPass
    {
        public string emailId { get; set; }
        public string empId { get; set; }
        public string OTP { get; set; }
        public string newPass { get; set; }
        public string confirmNewPass { get; set; }
    }
}
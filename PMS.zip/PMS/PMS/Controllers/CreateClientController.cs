﻿using System;
using System.Web.Mvc;
using PMS.Models;
using System.Data;
using MySql.Data.MySqlClient;
using System.Web;
using System.Web.Security;

namespace PMS.Controllers
{
    [Authorize]
    public class CreateClientController : Controller
    {
        //string connectionstring = @"Server=leap.chb6nt6repko.ap-southeast-1.rds.amazonaws.com;Database=leap2018;Uid=leap2018;Pwd=leap2018;SslMode=none";
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        string ID;
        String[] commandList;
        // GET: CreateClient
        public ActionResult CreateClient()
        {

            return View();
        }
        [HttpPost]
        public ActionResult CreateClient(CreateClient cc)
        {
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
            string name = ticket.Name;

            string genID = generateId(cc.client_name);
            bool flag = checkExistingClient(genID);//check if client exists
            if (flag == true)
            {
                //client is new
            
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open();
                MySqlCommand sqlCmd = new MySqlCommand("enterClientData", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                //sqlCmd.Parameters.AddWithValue("cid", cc.client_name.Substring(0,4));
                sqlCmd.Parameters.AddWithValue("cid", genID);
                //ID = cc.client_name.Substring(0, 4);
                //  Session["clientId"] = cc.client_name.Substring(0, 4); //store id in session
                Session["clientId"] = genID;
                sqlCmd.Parameters.AddWithValue("cn", cc.client_name);
                sqlCmd.Parameters.AddWithValue("cw", cc.client_website);
                sqlCmd.Parameters.AddWithValue("cnum", cc.client_contactnumber);
                sqlCmd.Parameters.AddWithValue("addr1", cc.client_address1);
                sqlCmd.Parameters.AddWithValue("addr2", cc.client_address2);
                sqlCmd.Parameters.AddWithValue("ct", cc.clientcity);
                sqlCmd.Parameters.AddWithValue("st", cc.clientstate);
                sqlCmd.Parameters.AddWithValue("zp", cc.clientzip);
                sqlCmd.Parameters.AddWithValue("cntry", cc.clientcountry);
                sqlCmd.Parameters.AddWithValue("cb", name);
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();
            }
                TempData["msg"] = "<script>alert('Details Saved Successfully');</script>";
                return View("CreateClient");
            }
            else
            {
                TempData["msg"] = "<script>alert('Client Already Registered');</script>";
                return View("CreateClient");
            }
        }
        [HttpPost]
        public ActionResult CreateClientContact(CreateClient cont)
        {
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
            string name = ticket.Name;
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open();
                MySqlCommand sqlCmd = new MySqlCommand("addClientContactDetails", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("cid", Convert.ToString(Session["clientId"]));
                sqlCmd.Parameters.AddWithValue("contactName", cont.ClientContactName);
                sqlCmd.Parameters.AddWithValue("contactTitle", cont.ContactPersonTitle);
                sqlCmd.Parameters.AddWithValue("contactEmail", cont.ClientContactEmail);
                sqlCmd.Parameters.AddWithValue("addr1", cont.clientcontact_address1);
                sqlCmd.Parameters.AddWithValue("addr2", cont.clientcontact_address2);
                sqlCmd.Parameters.AddWithValue("c", cont.city);
                sqlCmd.Parameters.AddWithValue("st", cont.state);
                sqlCmd.Parameters.AddWithValue("zp", cont.zip);
                sqlCmd.Parameters.AddWithValue("cntry", cont.country);
                sqlCmd.Parameters.AddWithValue("cb", name);
                //sqlCmd.Parameters.AddWithValue("bnk", cont.clientBankName);
                //sqlCmd.Parameters.AddWithValue("accnt", cont.clientBankAccountNumber);
                //sqlCmd.Parameters.AddWithValue("accntName", cont.clientAccountName);
                //sqlCmd.Parameters.AddWithValue("ifsc", cont.clientAccountIFSC);
                //sqlCmd.Parameters.AddWithValue("branch", cont.clientBankBranch);
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();
            }
            //return View("CreateClient");
            return RedirectToAction("Viewdata", "ViewClientData");
        }
     private string generateId(string name)
        {
            string upperName = name.ToUpper();
            string n;
            
            int count = 0;
            if (upperName.Length < 4)
               Session["id"] = upperName.Substring(0, upperName.Length);
            else
            {
               
                for (int i = 0; i < upperName.Length; i++)
                {
                    commandList = upperName.Split(new char[] { ' ' });
                   
                }
                count = commandList.Length;
                if (count == 1)
                {
                    Session["id"] = upperName.Substring(0, 4);
                }
                if(count == 2)
                {
                    Session["id"] = commandList[0].Substring(0, 2) + commandList[1].Substring(0, 2);
                }
                if(count == 3)
                {
                    Session["id"] = commandList[0].Substring(0, 2) + commandList[1].Substring(0, 1) + commandList[2].Substring(0, 1);
                }
                if(count >= 4)
                {
                    string s="";
                    for (int j = 0; j < commandList.Length ; j++)
                    {
                        s = s + commandList[j].Substring(0,1);
                    }
                    Session["id"] = s;
                }
            }
            n = Convert.ToString(Session["id"]);
            return n;
        }
        private bool checkExistingClient(string value)
        {
            string output;
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("checkIfClientExists", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("cId", value);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                output = dtbl.Rows[0]["result"].ToString();
            }
            if (output == "valid")
                return true;
            else
                return false;
        }

    }
}
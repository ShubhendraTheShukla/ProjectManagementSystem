﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PMS.Models;
using MySql.Data.MySqlClient;
using System.Data;
using System.Web.Security;

namespace PMS.Controllers
{
    [Authorize]
    public class editEmpProjectController : Controller
    {
        //string connectionstring = @"Server=leap.chb6nt6repko.ap-southeast-1.rds.amazonaws.com;Database=leap2018;Uid=leap2018;Pwd=leap2018;SslMode=none";
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: editEmpProject
        public ActionResult fetchEmpProject(string eId,string pId)
        {
            Session["employeeId"] = eId;
            Session["projectId"] = pId;
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("fetchProjectMap", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("pd", pId);
                sqlDA.SelectCommand.Parameters.AddWithValue("ed", eId);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                var cc = new viewEmployees();
                string sd = dtbl.Rows[0]["startdate"].ToString().Substring(0,10);
                string cd = dtbl.Rows[0]["enddate"].ToString().Substring(0,10);
                cc.empId = Convert.ToInt32(dtbl.Rows[0]["empId"].ToString());
                cc.projectcode = dtbl.Rows[0]["projectcode"].ToString();
                cc.startdate= sd.Substring(6, 4) + "-" + sd.Substring(3, 2) + "-" + sd.Substring(0, 2);
                cc.enddate= cd.Substring(6, 4) + "-" + cd.Substring(3, 2) + "-" + cd.Substring(0, 2);
                return View("empEdit",cc);
            }
                
        }
        [HttpPost]
        public ActionResult fetchEmpProject(viewEmployees cc)
        {
            string id = Convert.ToString(Session["projectId"]);
            int eid = Convert.ToInt32(Session["employeeId"]);
            bool flag = validateDates(id,cc.startdate,cc.enddate);
            if (flag == true)
            { 
                using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
                {
                    sqlCon.Open();
                    MySqlCommand sqlCmd = new MySqlCommand("updateProjectEmp", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("pd", id);
                    sqlCmd.Parameters.AddWithValue("eid", eid);
                    sqlCmd.Parameters.AddWithValue("sd", cc.startdate);
                    sqlCmd.Parameters.AddWithValue("ed", cc.enddate);
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
                return RedirectToAction("showEmployeeList", "ProjectAsset", new { i = id });
            }
            else
            {
                //alert
                Session["projectId"] = id;
                Session["employeeId"] = eid;
                TempData["msg"] = "<script>alert('Invalid Start and End Dates');</script>";
            }
            return RedirectToAction("fetchEmpProject", "editEmpProject", new {eId=Convert.ToString(eid),pId=id});
        }
        private bool validateDates(string pId,string sD,string eD)
        {
            string proStart, proEnd; //value of project
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("fetchSOWValue", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("pid", pId);
                DataTable dtbl = new DataTable(); //to create a local table
                sqlDA.Fill(dtbl); //pour data in data table
                sqlCon.Close();
                proStart = dtbl.Rows[0]["start_date"].ToString().Substring(0, 10);
                proEnd = dtbl.Rows[0]["completion_date"].ToString().Substring(0, 10);
            }
            DateTime pStartDate = Convert.ToDateTime(proStart); //project start date
            DateTime pEndDate = Convert.ToDateTime(proEnd); //project end date
            DateTime assetSD = Convert.ToDateTime(sD);
            DateTime assetED = Convert.ToDateTime(eD);
            int diffEntered = Convert.ToInt32((assetED - assetSD).TotalDays); //difference between entered dates
            int diffStart = Convert.ToInt32((assetSD - pStartDate).TotalDays); //difference between entered sd and proj sd
            int diffEnd = Convert.ToInt32((pEndDate - assetED).TotalDays); //difference between entered ed and proj ed 
            if (diffEntered >= 0 && diffStart >= 0 && diffEnd >= 0)
            {
                return true;
            }
            else
                return false;
        }
    }
}
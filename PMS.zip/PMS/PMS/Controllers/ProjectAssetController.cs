﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PMS.Models;
using MySql.Data.MySqlClient;
using System.Data;
using System.Web.Security;
using System.Net.Mail;
using System.Net;

namespace PMS.Controllers
{
    [Authorize]
    public class ProjectAssetController : Controller
    {
        //string connectionString = @"Server=leap.chb6nt6repko.ap-southeast-1.rds.amazonaws.com;Database=leap2018;Uid=leap2018;Pwd=leap2018;SslMode=none";
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: ProjectAsset
        private List<MyListTable> loadList(string id)
        {
            var l = new List<MyListTable>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionString)) //to create a new sql connection
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("viewEmpEmail", sqlCon); //stored procedure to view all products
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("pc", id);
                DataTable dtbl = new DataTable(); //to create a local table
                sqlDA.Fill(dtbl); //pour data in data table
                sqlCon.Close();
                int c = dtbl.Rows.Count;

                for (int k = 0; k < c; k++)
                {
                    var ud = new MyListTable();
                    ud.empId = Convert.ToInt32(dtbl.Rows[k]["empId"].ToString());
                    ud.empEmail = dtbl.Rows[k]["empEmail"].ToString();
                    l.Add(ud);
                    //(dtbl.Rows[0]["result"].ToString());
                }
                return l;
            }
        }
        public ActionResult showEmployeeList(string i,string sd,string ed)
        {
            Session["projSD"] = sd;
            Session["projED"] = ed;
                var model = new List<viewEmployees>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionString)) //to create a new sql connection
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("viewProjectMembers", sqlCon); //stored procedure to view all products
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("pc", i);
                DataTable dtbl = new DataTable(); //to create a local table
                sqlDA.Fill(dtbl); //pour data in data table
                sqlCon.Close();
                int c = dtbl.Rows.Count;
                if (c == 0)
                {
                    var em = new viewEmployees();
                    em.projectcode = i;
                    int? value = null;
                    em.empId =value;
                    var list = new List<MyListTable>();
                    list = loadList(i);               
                    em.elist = list;
                    model.Add(em);
                }
                else
                {
                    for (int j = 0; j < c; j++)
                    {
                        var ud = new viewEmployees();
                        ud.empId = Convert.ToInt32(dtbl.Rows[j]["empId"].ToString());
                        ud.startdate = Convert.ToString(dtbl.Rows[j]["startdate"]).Substring(0, 10);
                        ud.enddate = Convert.ToString(dtbl.Rows[j]["enddate"]).Substring(0, 10);
                        ud.projectcode = dtbl.Rows[j]["projectcode"].ToString();
                        ud.firstname = dtbl.Rows[j]["empfirstname"].ToString();
                        ud.lastname = dtbl.Rows[j]["emplastname"].ToString();
                        var list = new List<MyListTable>();
                        list = loadList(i);
                        ud.elist = list;
                        model.Add(ud);
                    }
                }
            }
            return View("showEmp",model);
        }
        [HttpPost]
        public ActionResult showEmployeeList(viewEmployees ve)
        {
            bool flag = verifyDates(ve.startdate, ve.enddate,ve.projectcode);
            if (flag == true)
            { 
                //all dates correct
                using (MySqlConnection sqlCon = new MySqlConnection(connectionString))
                {
                    sqlCon.Open();
                    MySqlCommand sqlCmd = new MySqlCommand("addEmpProject", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("em", ve.empEmail);
                    sqlCmd.Parameters.AddWithValue("pc", ve.projectcode);
                    sqlCmd.Parameters.AddWithValue("sd", Convert.ToDateTime(ve.startdate));
                    sqlCmd.Parameters.AddWithValue("ed", Convert.ToDateTime(ve.enddate));
                    sqlCmd.ExecuteNonQuery();
                    sendEmail(ve.empEmail, ve.projectcode, ve.startdate, ve.enddate);
                    sqlCon.Close();

                }
                //return RedirectToAction("showEmployeeList", "ProjectAsset", new { i = ve.projectcode });
            }
            else
            { 
                TempData["msg"] = "<script>alert('Check To and From Dates');</script>";
            }
            return RedirectToAction("showEmployeeList", "ProjectAsset", new { i = ve.projectcode });

        }

        private bool verifyDates(string sD,string eD,string pId)
        {
            string proStart, proEnd; //value of project
            using (MySqlConnection sqlCon = new MySqlConnection(connectionString))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("fetchSOWValue", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("pid", pId);
                DataTable dtbl = new DataTable(); //to create a local table
                sqlDA.Fill(dtbl); //pour data in data table
                sqlCon.Close();
                proStart = dtbl.Rows[0]["start_date"].ToString().Substring(0, 10);
                proEnd = dtbl.Rows[0]["completion_date"].ToString().Substring(0, 10);
            }
            DateTime pStartDate = Convert.ToDateTime(proStart); //project start date
            DateTime pEndDate = Convert.ToDateTime(proEnd); //project end date
            DateTime assetSD = Convert.ToDateTime(sD);
            DateTime assetED = Convert.ToDateTime(eD);
            int diffEntered = Convert.ToInt32((assetED - assetSD).TotalDays); //difference between entered dates
            int diffStart= Convert.ToInt32((assetSD - pStartDate).TotalDays); //difference between entered sd and proj sd
            int diffEnd = Convert.ToInt32((pEndDate - assetED).TotalDays); //difference between entered ed and proj ed 
            if(diffEntered >= 0 && diffStart >= 0 && diffEnd >=0)
            {
                return true;
            }
            else
            return false;
        }

        //sends email to employee mapped to project
        private void sendEmail(string toEmail,string prCode,string strtDate,string endDt)
        {
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
            string name = ticket.Name;
            string prName = "", emName = "", pMngr = "",frEmail="",pwd="";
            //fetch Values
            using (MySqlConnection sqlCon = new MySqlConnection(connectionString)) //to create a new sql connection
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("fetchProjectDetails", sqlCon); //stored procedure to view all products
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("pid", prCode);
                sqlDA.SelectCommand.Parameters.AddWithValue("em", toEmail);
                sqlDA.SelectCommand.Parameters.AddWithValue("pm", name);
                DataTable dtbl = new DataTable(); //to create a local table
                sqlDA.Fill(dtbl); //pour data in data table
                prName = dtbl.Rows[0]["projName"].ToString();
                emName = dtbl.Rows[0]["empName"].ToString();
                pMngr = dtbl.Rows[0]["projMngr"].ToString();
                frEmail= dtbl.Rows[0]["frmEmail"].ToString();
                pwd= dtbl.Rows[0]["pass"].ToString();
                sqlCon.Close();
            }

            //trigger Email

            string fromaddr = frEmail;
            string password = pwd;
            MailMessage msg = new MailMessage();
            msg.Subject = "Project Onboarding Notification";
            msg.From = new MailAddress(fromaddr);
            msg.Body = "Dear" + " " + emName + "," + "\r\n" + "Welcome to the project. You have been mapped to project "+prCode +" under "+pMngr+ "\r\n" + "You will be billed under this project from "+ strtDate +" to "+endDt +"\r\n" + "Contribute to make this project a success." + "\r\n" +"For any query revert back to us or reach your manager."+"\r\n"+ "Regards" + "\r\n" + "Team PMS";
            msg.To.Add(new MailAddress(toEmail));
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.office365.com";
            smtp.Port = 587;
            smtp.UseDefaultCredentials = false;
            smtp.EnableSsl = true;
            NetworkCredential nc = new NetworkCredential(fromaddr, password);
            smtp.Credentials = nc;
            smtp.Send(msg);
        }
        //[HttpPost]
        //public ActionResult viewFilterData(viewEmployees ve)
        //{

        //    return View();
        //}


    }
}
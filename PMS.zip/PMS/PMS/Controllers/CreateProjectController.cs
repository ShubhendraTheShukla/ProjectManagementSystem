﻿using System;
using System.Web.Mvc;
using PMS.Models;
using System.Data;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;

namespace PMS.Controllers
{
    [Authorize]
    public class CreateProjectController : Controller
    {
        //string connectionstring = @"Server=leap.chb6nt6repko.ap-southeast-1.rds.amazonaws.com;Database=leap2018;Uid=leap2018;Pwd=leap2018;SslMode=none";
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: CreateProject
        private List<clientList> loadClients()
        {
            var l = new List<clientList>();
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
            string name = ticket.Name;
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring)) //to create a new sql connection
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("fetchClients", sqlCon); //stored procedure to view all products
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("em", name);
                DataTable dtbl = new DataTable(); //to create a local table
                sqlDA.Fill(dtbl); //pour data in data table
                sqlCon.Close();
                int c = dtbl.Rows.Count;

                for (int k = 0; k < c; k++)
                {
                    var ud = new clientList();
                    ud.client_name = (dtbl.Rows[k]["client_name"].ToString());              
                    l.Add(ud);
                }
                return l;
            }
        }
        public ActionResult CreateProject()
        {
            var model = new List<CreateProject>();
            var list = new List<clientList>();
            list = loadClients();
            var cl = new CreateProject();
            cl.clients = list;
            model.Add(cl);
            return View("CreateProject",model);
        }
        [HttpPost]
        public ActionResult CreateProject(CreateProject cp)
        {
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
            string name = ticket.Name;
            DateTime sd = Convert.ToDateTime(cp.start_date);
            DateTime cd = Convert.ToDateTime(cp.completion_date);
            int diff = Convert.ToInt32((cd - sd).TotalDays);
            double nod = countWeekdays(sd, cd); //count number of weekdays
            double hours = nod * 8;
            double billRate = Convert.ToDouble(cp.sow_value.Substring(1, cp.sow_value.Length-1))/(hours);
            if (diff >= 0)
            { 
                using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
                {
                    sqlCon.Open();
                    MySqlCommand sqlCmd = new MySqlCommand("EnterProjectData", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    //sqlCmd.Parameters.AddWithValue("pi", cp.project_id);
                    sqlCmd.Parameters.AddWithValue("cn", cp.client_name);
                    sqlCmd.Parameters.AddWithValue("pn", cp.project_name);
                    sqlCmd.Parameters.AddWithValue("sv", cp.sow_value);
                    sqlCmd.Parameters.AddWithValue("sd", Convert.ToDateTime(cp.start_date));
                    sqlCmd.Parameters.AddWithValue("cd", Convert.ToDateTime(cp.completion_date));
                    sqlCmd.Parameters.AddWithValue("pm", name);
                    sqlCmd.Parameters.AddWithValue("br", "$"+Convert.ToString(billRate));
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
                return RedirectToAction("viewdata", "viewProjectData");
            }
            else
            {
                TempData["msg"] = "<script>alert('Check Start and End Dates');</script>";
                var model = new List<CreateProject>();
                var list = new List<clientList>();
                list = loadClients();
                var cl = new CreateProject();
                cl.clients = list;
                model.Add(cl);
                return View("CreateProject", model);
            }
        }
        private double countWeekdays(DateTime startD,DateTime endD)
        {
            double calcBusinessDays =
        1 + ((endD - startD).TotalDays * 5 -
        (startD.DayOfWeek - endD.DayOfWeek) * 2) / 7;

            if (endD.DayOfWeek == DayOfWeek.Saturday) calcBusinessDays--;
            if (startD.DayOfWeek == DayOfWeek.Sunday) calcBusinessDays--;

            return calcBusinessDays;
            
        }

    }
}
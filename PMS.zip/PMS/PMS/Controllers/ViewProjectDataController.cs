﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PMS.Models;
using MySql.Data.MySqlClient;
using System.Data;
using System.Web.Security;

namespace PMS.Controllers
{
    [Authorize]
    public class ViewProjectDataController : Controller
    {
        //string connectionstring = @"Server=leap.chb6nt6repko.ap-southeast-1.rds.amazonaws.com;Database=leap2018;Uid=leap2018;Pwd=leap2018;SslMode=none";
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: ViewProjectData
        public ActionResult Viewdata()
        {
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
            string name = ticket.Name;
            var model = new List<CreateProject>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("ViewProjectData", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("em", name);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                int c = dtbl.Rows.Count;
                for (int i = 0; i < c; i++)
                {
                    var cp = new CreateProject();
                    cp.client_id = dtbl.Rows[i]["client_id"].ToString();
                    cp.project_id = dtbl.Rows[i]["project_id"].ToString();
                    cp.project_name = dtbl.Rows[i]["project_name"].ToString();
                    cp.sow_value = dtbl.Rows[i]["sow_value"].ToString();
                    cp.start_date =Convert.ToString(dtbl.Rows[i]["start_date"]).Substring(0,10);
                    cp.completion_date= Convert.ToString(dtbl.Rows[i]["completion_date"]).Substring(0, 10);
                    model.Add(cp);
                }
                return View("ViewProject",model);

            }
        }
        [HttpPost]
        public ActionResult Viewdata(CreateProject pp)
        {
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
            string name = ticket.Name;
            var model = new List<CreateProject>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("ViewProjectDataFilter", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("em", name);
                sqlDA.SelectCommand.Parameters.AddWithValue("keyword", pp.keyword);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                int c = dtbl.Rows.Count;
                for (int i = 0; i < c; i++)
                {
                    var cp = new CreateProject();
                    cp.client_id = dtbl.Rows[i]["client_id"].ToString();
                    cp.project_id = dtbl.Rows[i]["project_id"].ToString();
                    cp.project_name = dtbl.Rows[i]["project_name"].ToString();
                    cp.sow_value = dtbl.Rows[i]["sow_value"].ToString();
                    cp.start_date = Convert.ToString(dtbl.Rows[i]["start_date"]).Substring(0, 10);
                    cp.completion_date = Convert.ToString(dtbl.Rows[i]["completion_date"]).Substring(0, 10);
                    model.Add(cp);
                }
                return View("ViewProject", model);

            }
        }
       
    }
}



﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PMS.Models;
using MySql.Data.MySqlClient;
using System.Data;
using System.Web.Security;

namespace PMS.Controllers
{
    [Authorize]
    public class editProjectController : Controller
    {
        //string connectionstring = @"Server=leap.chb6nt6repko.ap-southeast-1.rds.amazonaws.com;Database=leap2018;Uid=leap2018;Pwd=leap2018;SslMode=none";
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: editProject
        public ActionResult fetchProjectData(string i)
        {
            Session["projectId"] = i;
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("fetchProjectDetailsId", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("pid", i);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                var cp = new CreateProject();
                cp.client_name= dtbl.Rows[0]["client_name"].ToString();
                cp.sow_value = dtbl.Rows[0]["sow_value"].ToString();
                string sd= dtbl.Rows[0]["start_date"].ToString().Substring(0,10);
                string cd = dtbl.Rows[0]["completion_date"].ToString().Substring(0, 10);
                cp.start_date = sd.Substring(6,4)+"-"+sd.Substring(3,2)+"-"+sd.Substring(0,2);
                cp.completion_date = cd.Substring(6, 4) + "-" + cd.Substring(3, 2) + "-" + cd.Substring(0, 2);
                cp.project_name = dtbl.Rows[0]["project_name"].ToString();
                return View("editProjectData", cp);
            }
                
        }
        [HttpPost]
        public ActionResult fetchProjectData(CreateProject cc)
        {
            string id = Convert.ToString(Session["projectId"]);
            DateTime sd = Convert.ToDateTime(cc.start_date);
            DateTime cd = Convert.ToDateTime(cc.completion_date);
            int diff = Convert.ToInt32((cd - sd).TotalDays);
            if (diff >= 0)
            { 
                using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
                {
                    sqlCon.Open();
                    MySqlCommand sqlCmd = new MySqlCommand("updateProject", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("pid", Convert.ToString(Session["projectId"]));
                    sqlCmd.Parameters.AddWithValue("sv", cc.sow_value);
                    sqlCmd.Parameters.AddWithValue("sd", cc.start_date);
                    sqlCmd.Parameters.AddWithValue("cd", cc.completion_date);
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
                return RedirectToAction("Viewdata", "ViewProjectData");
            }
            else
            {
                //alert
                TempData["msg"] = "<script>alert('Invalid Start and End Dates');</script>";
                Session["projectId"] = id;
            }
            return RedirectToAction("fetchProjectData", "editProject",new {i=id });
        }
    }
}
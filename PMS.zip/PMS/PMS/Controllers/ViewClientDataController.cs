﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PMS.Models;
using MySql.Data.MySqlClient;
using System.Data;
using System.Web.Security;

namespace PMS.Controllers
{
    [Authorize]
    public class ViewClientDataController : Controller
    {
        //string connectionstring = @"Server=leap.chb6nt6repko.ap-southeast-1.rds.amazonaws.com;Database=leap2018;Uid=leap2018;Pwd=leap2018;SslMode=none";
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: ViewClientData
        public ActionResult Viewdata()
        {
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
            string name = ticket.Name;
            var model = new List<CreateClient>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("ViewClientData", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("em", name);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                int c = dtbl.Rows.Count;

                for (int i = 0; i < c; i++)
                {
                    var cc = new CreateClient();
                    cc.client_id = dtbl.Rows[i]["client_id"].ToString();
                    cc.client_name = dtbl.Rows[i]["client_name"].ToString();
                    cc.client_website = dtbl.Rows[i]["client_website"].ToString();
                    cc.client_contactnumber = dtbl.Rows[i]["client_contactnumber"].ToString();
                    model.Add(cc);
                    //(dtbl.Rows[0]["result"].ToString());

                }


                return View(model);
            }


        }
        [HttpPost]
        public ActionResult Viewdata(CreateClient ck)
        {
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
            string name = ticket.Name;
            var model = new List<CreateClient>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("viewClientDataFilter", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("keyword", ck.keyword);
                sqlDA.SelectCommand.Parameters.AddWithValue("em", name);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                int c = dtbl.Rows.Count;

                for (int i = 0; i < c; i++)
                {
                    var cc = new CreateClient();
                    cc.client_id = dtbl.Rows[i]["client_id"].ToString();
                    cc.client_name = dtbl.Rows[i]["client_name"].ToString();
                    cc.client_website = dtbl.Rows[i]["client_website"].ToString();
                    cc.client_contactnumber = dtbl.Rows[i]["client_contactnumber"].ToString();
                    model.Add(cc);
                    //(dtbl.Rows[0]["result"].ToString());

                }
                return View("Viewdata", model);
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PMS.Models;
using MySql.Data.MySqlClient;
using System.Data;
using System.Web.Security;

namespace PMS.Controllers
{
    [Authorize]
    public class editClientController : Controller
    {
        //string connectionstring = @"Server=leap.chb6nt6repko.ap-southeast-1.rds.amazonaws.com;Database=leap2018;Uid=leap2018;Pwd=leap2018;SslMode=none";
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: editClient
        public ActionResult fetchClientDetails(string i)
        {
            //fetch values of selected client
            //var model = new List<CreateClient>();
            Session["clientId"] = i;
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("fetchCLientDetails", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("cid", i);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                var cc = new CreateClient();
                cc.city = dtbl.Rows[0]["city"].ToString();
                //cc.clientAccountIFSC = dtbl.Rows[0]["clientAccountIFSC"].ToString();
                //cc.clientAccountName = dtbl.Rows[0]["clientAccountName"].ToString();
                //cc.clientBankAccountNumber = dtbl.Rows[0]["clientBankAccountNumber"].ToString();
                //cc.clientBankBranch = dtbl.Rows[0]["clientBankBranch"].ToString();
                //cc.clientBankName = dtbl.Rows[0]["clientBankName"].ToString();
                cc.clientcity = dtbl.Rows[0]["clientcity"].ToString();
                cc.ClientContactEmail = dtbl.Rows[0]["ClientContactEmail"].ToString();
                cc.ClientContactName = dtbl.Rows[0]["ClientContactName"].ToString(); 
                cc.clientcontact_address1 = dtbl.Rows[0]["clientcontact_address1"].ToString(); 
                cc.clientcontact_address2 = dtbl.Rows[0]["clientcontact_address2"].ToString();
                cc.clientcountry = dtbl.Rows[0]["clientcountry"].ToString();
                cc.clientstate = dtbl.Rows[0]["clientstate"].ToString();
                cc.clientzip = dtbl.Rows[0]["clientzip"].ToString();
                cc.client_address1 = dtbl.Rows[0]["client_address1"].ToString(); 
                cc.client_address2 = dtbl.Rows[0]["client_address2"].ToString();
                cc.client_contactnumber = dtbl.Rows[0]["client_contactnumber"].ToString(); 
                cc.client_name = dtbl.Rows[0]["client_name"].ToString();
                cc.client_website = dtbl.Rows[0]["client_website"].ToString(); 
                cc.ContactPersonTitle = dtbl.Rows[0]["ContactPersonTitle"].ToString();
                cc.country = dtbl.Rows[0]["country"].ToString();
                cc.state = dtbl.Rows[0]["state"].ToString();
                cc.zip = dtbl.Rows[0]["zip"].ToString();
                return View("editClientDetail",cc);
            }
               
        }
        [HttpPost]
        public ActionResult updateClientDetails(CreateClient cc)
        {
            string id = Convert.ToString(Session["clientId"]);
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open();
                MySqlCommand sqlCmd = new MySqlCommand("updateClient", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                //sqlCmd.Parameters.AddWithValue("cid", cc.client_name.Substring(0,4));
                sqlCmd.Parameters.AddWithValue("cid", Convert.ToString(Session["clientId"]));
                //ID = cc.client_name.Substring(0, 4);
                //  Session["clientId"] = cc.client_name.Substring(0, 4); //store id in session
                //Session["clientId"] = genID;
                sqlCmd.Parameters.AddWithValue("cn", cc.client_name);
                sqlCmd.Parameters.AddWithValue("cw", cc.client_website);
                sqlCmd.Parameters.AddWithValue("cnum", cc.client_contactnumber);
                sqlCmd.Parameters.AddWithValue("addr1", cc.client_address1);
                sqlCmd.Parameters.AddWithValue("addr2", cc.client_address2);
                sqlCmd.Parameters.AddWithValue("ct", cc.clientcity);
                sqlCmd.Parameters.AddWithValue("st", cc.clientstate);
                sqlCmd.Parameters.AddWithValue("zp", cc.clientzip);
                sqlCmd.Parameters.AddWithValue("cntry", cc.clientcountry);
                //sqlCmd.Parameters.AddWithValue("cb", name);
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();
            }
            return RedirectToAction("fetchClientDetails", "editClient", new { i = id });
        }
        [HttpPost]
        public ActionResult updateClientContactDetails(CreateClient cont)
        {
            string id = Convert.ToString(Session["clientId"]);
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
            string name = ticket.Name;
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open();
                MySqlCommand sqlCmd = new MySqlCommand("updateClientContact", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("cid", Convert.ToString(Session["clientId"]));
                sqlCmd.Parameters.AddWithValue("contactName", cont.ClientContactName);
                sqlCmd.Parameters.AddWithValue("contactTitle", cont.ContactPersonTitle);
                sqlCmd.Parameters.AddWithValue("contactEmail", cont.ClientContactEmail);
                sqlCmd.Parameters.AddWithValue("addr1", cont.clientcontact_address1);
                sqlCmd.Parameters.AddWithValue("addr2", cont.clientcontact_address2);
                sqlCmd.Parameters.AddWithValue("c", cont.city);
                sqlCmd.Parameters.AddWithValue("st", cont.state);
                sqlCmd.Parameters.AddWithValue("zp", cont.zip);
                sqlCmd.Parameters.AddWithValue("cntry", cont.country);
                sqlCmd.Parameters.AddWithValue("cb", name);
                //sqlCmd.Parameters.AddWithValue("bnk", cont.clientBankName);
                //sqlCmd.Parameters.AddWithValue("accnt", cont.clientBankAccountNumber);
                //sqlCmd.Parameters.AddWithValue("accntName", cont.clientAccountName);
                //sqlCmd.Parameters.AddWithValue("ifsc", cont.clientAccountIFSC);
                //sqlCmd.Parameters.AddWithValue("branch", cont.clientBankBranch);
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();
            }
            return RedirectToAction("Viewdata", "ViewClientData");
        }
    }
}
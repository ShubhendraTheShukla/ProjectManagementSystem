﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PMS.Models;
using MySql.Data.MySqlClient;
using System.Data;
using System.Web.Security;

namespace PMS.Controllers
{
    [Authorize]
    public class MilestoneController : Controller
    {
        // string pValue;
        //string connectionString = @"Server=leap.chb6nt6repko.ap-southeast-1.rds.amazonaws.com;Database=leap2018;Uid=leap2018;Pwd=leap2018;SslMode=none";
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: Milestone
        public ActionResult showMilestoneList(string i,string sd,string ed,string sv)
        {
            Session["proStart"] = sd;
            Session["proEnd"] = ed;
            Session["value"] = sv;
           // pValue = sv;
            long sumSOW = 0;
            var model = new List<viewMilestone>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionString))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("viewProjectMilestones", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("pi", i);
                DataTable dtbl = new DataTable(); //to create a local table
                sqlDA.Fill(dtbl); //pour data in data table
                sqlCon.Close();
                int c = dtbl.Rows.Count;
                if (c == 0)
                {
                    var ms = new viewMilestone();
                    ms.project_id = i;
                    string value = null;
                    ms.milestone_id = value;
                    model.Add(ms);


                }
                else
                {
                    for (int j = 0; j < c; j++)
                    {
                        var ud = new viewMilestone();
                        ud.milestone_id = dtbl.Rows[j]["milestone_id"].ToString();
                        ud.milestone_date = Convert.ToString(dtbl.Rows[j]["milestone_date"]).Substring(0, 10);
                        ud.sow_value = dtbl.Rows[j]["sow_value"].ToString();
                        long val= Convert.ToInt64(dtbl.Rows[j]["sow_value"].ToString().Substring(1,ud.sow_value.Length-1));
                        sumSOW = sumSOW + val;
                        ud.project_id = dtbl.Rows[j]["project_id"].ToString();
                        model.Add(ud);
                    }
                    Session["lastMileDate"] = dtbl.Rows[dtbl.Rows.Count-1]["milestone_date"].ToString().Substring(0, 10);
                    string lm = Convert.ToString(Session["lastMileDate"]);
                    Session["sowMile"] = sumSOW;
                }
            }
            return View("showMile", model);
        }
        [HttpPost]
        public ActionResult showMilestoneList(viewMilestone vm)
        {
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
            string name = ticket.Name;
            bool flagDate = validateDates(vm.milestone_date,vm.project_id); //validate dates entered
            bool flagSOW = validateSOW(vm.sow_value,vm.project_id); //validate sow value enetered
            Session["pid"] = vm.project_id;
            if (flagDate == true)
            { //dates are correct
                if (flagSOW == true)
                { //sow value is correct}
                    using (MySqlConnection sqlCon = new MySqlConnection(connectionString))
                    {
                        sqlCon.Open();
                        MySqlCommand sqlCmd = new MySqlCommand("addMilestoneProject", sqlCon);
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("pi", vm.project_id);
                        //sqlCmd.Parameters.AddWithValue("mi", vm.milestone_id);
                        sqlCmd.Parameters.AddWithValue("md", Convert.ToDateTime(vm.milestone_date));
                        sqlCmd.Parameters.AddWithValue("sv", vm.sow_value);
                        sqlCmd.Parameters.AddWithValue("pm", name);
                        sqlCmd.ExecuteNonQuery();
                        sqlCon.Close();
                        //Session["lastMileDate"] = "";
                    }
                }
                else
                {
                    TempData["msg"] = "<script>alert('SOW Value Not Correct');</script>";   //sow is incorrect
                }
            }
            else
            {
                //dates are wrong
                TempData["msg"] = "<script>alert('Check Milestone Dates');</script>";
            }
            return RedirectToAction("showMilestoneList", "Milestone",new { i = vm.project_id });
        }
        private bool validateDates(string md,string pId)
        {
            string proStart,proEnd,lastMile; //value of project
            using (MySqlConnection sqlCon = new MySqlConnection(connectionString))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("fetchSOWValue", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("pid", pId);
                DataTable dtbl = new DataTable(); //to create a local table
                sqlDA.Fill(dtbl); //pour data in data table
                sqlCon.Close();
                proStart = dtbl.Rows[0]["start_date"].ToString().Substring(0,10);
                proEnd = dtbl.Rows[0]["completion_date"].ToString().Substring(0,10);
            }
            using (MySqlConnection sqlCon = new MySqlConnection(connectionString))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("fetchLastMileData", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("proj", pId);
                DataTable dtbl = new DataTable(); //to create a local table
                sqlDA.Fill(dtbl); //pour data in data table
                sqlCon.Close();
               string last = dtbl.Rows[0]["milestone_date"].ToString();
                //if (last.Length != 0)
                    lastMile = last.Substring(0, 10);
                //else
                //    lastMile = "01-01-1900";
                //proEnd = dtbl.Rows[0]["completion_date"].ToString().Substring(0, 10);
            }
            DateTime pStart = Convert.ToDateTime(proStart); //project start date
            DateTime pEnd = Convert.ToDateTime(proEnd);//project end date
            DateTime msDate = Convert.ToDateTime(md);//entered milestone date
            DateTime lastMSDate = Convert.ToDateTime(lastMile);
                //Convert.ToDateTime(Session["lastMileDate"]); //date of last milestone created
            int diff1= Convert.ToInt32((msDate - pStart).TotalDays);//ms date should be greater than start date of project
            int diff2 = Convert.ToInt32((pEnd - msDate).TotalDays);//ms date should be less than project end date
            int diff3 = Convert.ToInt32((msDate - lastMSDate).TotalDays);//ms date should be greater than last entered ms
            if (diff1 >= 0 && diff2 >= 0 && diff3 >= 0)
                return true;
            else
                return false;
        }
        private bool validateSOW(string msSOW,string pId)
        {
            //fetch  sow value of project
            string pValue; //value of project
            using (MySqlConnection sqlCon = new MySqlConnection(connectionString))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("fetchSOWValue", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("pid", pId);
                DataTable dtbl = new DataTable(); //to create a local table
                sqlDA.Fill(dtbl); //pour data in data table
                sqlCon.Close();
                pValue = dtbl.Rows[0]["sow_value"].ToString();
            }
            string val = pValue;
            long projValue = Convert.ToInt64(val.Substring(1,val.Length-1)); //convert it to int
            long totMSValueEntered = Convert.ToInt64(Session["sowMile"]); //total value of MS till now entered
            long msEntered = Convert.ToInt64(msSOW.Substring(1, msSOW.Length - 1));
            long diff = projValue - totMSValueEntered;//difference of proj value and total ms value till now should be greater than zero
            //the value of ms entered should be less than or equal to difference left
            if(diff > 0 && msEntered <= diff)
            {            
                return true;           
            }
            else
                return false;
        }
        

    }
}
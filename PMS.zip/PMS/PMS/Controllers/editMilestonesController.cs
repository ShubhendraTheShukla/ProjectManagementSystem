﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PMS.Models;
using MySql.Data.MySqlClient;
using System.Data;
using System.Web.Security;

namespace PMS.Controllers
{
    [Authorize]
    public class editMilestonesController : Controller
    {
        //string connectionstring = @"Server=leap.chb6nt6repko.ap-southeast-1.rds.amazonaws.com;Database=leap2018;Uid=leap2018;Pwd=leap2018;SslMode=none";
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: editMilestones
        public ActionResult editMilestone(string mileId,string prId)
        {
            Session["milestoneId"] = mileId;
            Session["projectId"] = prId;
           
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("viewMilestoneId", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("mid", mileId);
                sqlDA.SelectCommand.Parameters.AddWithValue("pd", prId);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                var cc = new viewMilestone();
                string md = dtbl.Rows[0]["milestone_date"].ToString().Substring(0, 10);
                cc.sow_value = (dtbl.Rows[0]["sow_value"].ToString());
                //cc.projectcode = dtbl.Rows[0]["projectcode"].ToString();
                cc.milestone_date = md.Substring(6, 4) + "-" + md.Substring(3, 2) + "-" + md.Substring(0, 2);
                cc.project_id=prId;
                cc.milestone_id = mileId;
                return View("editMiles", cc);
            }
            //return View("editMiles");
        }
        [HttpPost]
        public ActionResult editMilestone(viewMilestone vm)
        {
            string projId = Convert.ToString(Session["projectId"]);
            string milesId = Convert.ToString(Session["milestoneId"]);
            string strtDate, endDate, softVal;
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("fetchSOWValue", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("pid", vm.project_id);
                DataTable dtbl = new DataTable(); //to create a local table
                sqlDA.Fill(dtbl); //pour data in data table
                sqlCon.Close();
                softVal = dtbl.Rows[0]["sow_value"].ToString();
                strtDate = dtbl.Rows[0]["start_date"].ToString().Substring(0, 10);
                endDate = dtbl.Rows[0]["completion_date"].ToString().Substring(0, 10);
            }
            bool flag = validateNewMileStones(vm.project_id, vm.milestone_id, vm.sow_value, vm.milestone_date);
            if (flag == true)
            { 
                using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
                {
                    sqlCon.Open();
                    MySqlCommand sqlCmd = new MySqlCommand("updateMilestoneId", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("mid", vm.milestone_id);
                    sqlCmd.Parameters.AddWithValue("pd", vm.project_id);
                    sqlCmd.Parameters.AddWithValue("md", vm.milestone_date);
                    sqlCmd.Parameters.AddWithValue("sv", vm.sow_value);
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();
                    //string i,string sd,string ed,string sv
                }
                return RedirectToAction("showMilestoneList", "Milestone", new { i = vm.project_id, sd = strtDate, ed = endDate, sv = softVal });
            }
            else
            {
                //alert for checking mile date and sow
                TempData["msg"] = "<script>alert('Invalid Milestone Date or SOW Value');</script>";
            }
            return RedirectToAction("editMilestone", "editMilestones", new { mileId = vm.milestone_id, prId = vm.project_id });
        }
        private bool validateNewMileStones(string pId,string mId,string newSOW,string mileDate)
        {
            string proStart, proEnd, mileSOW, milePrev, mileNext;
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("validateUpdateMilestone", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("mileId", mId);
                sqlDA.SelectCommand.Parameters.AddWithValue("projId", pId);
                DataTable dtbl = new DataTable(); //to create a local table
                sqlDA.Fill(dtbl); //pour data in data table
                sqlCon.Close();
                mileSOW = dtbl.Rows[0]["SOW"].ToString();
                proStart = dtbl.Rows[0]["projStart"].ToString().Substring(0, 10);
                proEnd = dtbl.Rows[0]["projEnd"].ToString().Substring(0, 10);
                milePrev= dtbl.Rows[0]["prevMile"].ToString().Substring(0, 10);
                mileNext= dtbl.Rows[0]["nextMile"].ToString().Substring(0, 10);
            }
            DateTime pStart = Convert.ToDateTime(proStart); //project start date
            DateTime pEnd = Convert.ToDateTime(proEnd);//project end date
            DateTime mPrev = Convert.ToDateTime(milePrev);//entered milestone date
            DateTime mNext = Convert.ToDateTime(mileNext);
            DateTime mDate = Convert.ToDateTime(mileDate);
            int diff1 = Convert.ToInt32((mDate - pStart).TotalDays);//ms date should be greater than start date of project
            int diff2 = Convert.ToInt32((pEnd - mDate).TotalDays);//ms date should be less than project end date
            int diff3 = Convert.ToInt32((mDate - mPrev).TotalDays);//ms date should be greater than previuos mile date
            int diff4 = Convert.ToInt32((mNext - mDate).TotalDays);//ms date should be less than next mile date
            long newValue = Convert.ToInt64(newSOW.Substring(1, newSOW.Length - 1));
            long mVal = Convert.ToInt64(mileSOW);
            if (diff1 >= 0 && diff2 >= 0 && diff3 > 0 && diff4 > 0 && newValue <= mVal)
                return true;
            else
            return false;
        }
    }
}
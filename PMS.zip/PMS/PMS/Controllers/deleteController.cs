﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PMS.Models;
using MySql.Data.MySqlClient;
using System.Data;
using System.Web.Security;

namespace PMS.Controllers
{
    public class deleteController : Controller
    {
        // GET: delete
        //string connectionString = @"Server=leap.chb6nt6repko.ap-southeast-1.rds.amazonaws.com;Database=leap2018;Uid=leap2018;Pwd=leap2018;SslMode=none";
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        public ActionResult deleteMilestone(string mileId,string prId)
        {
            //string id = Convert.ToString(Session["pid"]);
            using (MySqlConnection sqlCon = new MySqlConnection(connectionString))
            {
                sqlCon.Open();
                MySqlCommand sqlCmd = new MySqlCommand("deleteMilestone", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("mid", mileId);
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();
            }
            return RedirectToAction("showMilestoneList", "Milestone", new { i = prId });
        }
        public ActionResult deleteProjectEmp(string empId, string prId)
        {
            //string id = Convert.ToString(Session["pid"]);
            using (MySqlConnection sqlCon = new MySqlConnection(connectionString))
            {
                sqlCon.Open();
                MySqlCommand sqlCmd = new MySqlCommand("deleteEmp", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("eId", Convert.ToInt32(empId));
                sqlCmd.Parameters.AddWithValue("pId", prId);
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();
            }
            return RedirectToAction("showEmployeeList", "ProjectAsset", new { i = prId });
        }
    }
}
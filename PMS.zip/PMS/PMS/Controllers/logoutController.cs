﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PMS.Models;
using MySql.Data.MySqlClient;
using System.Data;
using System.Web.Security;

namespace PMS.Controllers
{
    public class logoutController : Controller
    {
        //string connectionString = @"Server=leap.chb6nt6repko.ap-southeast-1.rds.amazonaws.com;Database=leap2018;Uid=leap2018;Pwd=leap2018;SslMode=none";
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: logout
        public ActionResult signOut()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("loginView", "Login");
        }
    }
}
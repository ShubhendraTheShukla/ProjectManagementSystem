﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PMS.Models;
using MySql.Data.MySqlClient;
using System.Data;
using System.Web.Security;
using System.Net.Mail;
using System.Net;

namespace PMS.Controllers
{
    [AllowAnonymous]
    public class forgotPasswordController : Controller
    {
        //string connectionString = @"Server=leap.chb6nt6repko.ap-southeast-1.rds.amazonaws.com;Database=leap2018;Uid=leap2018;Pwd=leap2018;SslMode=none";
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: forgotPassword
        public ActionResult enterDetails()
        {
            return View("resetPass");
        }
        [HttpPost]
        public ActionResult enterDetails(forgotPass fp)
        {
            //string toEmail;
            //check and generate otp
            using (MySqlConnection sqlCon = new MySqlConnection(connectionString))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("verifyCredentials", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("em", fp.emailId);
                sqlDA.SelectCommand.Parameters.AddWithValue("eid", fp.empId);
                Session["employeeId"] = fp.empId;
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                if (dtbl.Rows[0]["result"].ToString() == "found")
                    Session["toEmail"] = dtbl.Rows[0]["empEmail"].ToString();
                if (dtbl.Rows[0]["result"].ToString() == "no data")
                {
                    TempData["msg"] = "<script>alert('User Not Found');</script>";
                    return View("resetPass");
                }
            }
            //generate OTP
            Random r = new Random();
            int randNum = r.Next(1000000);
            string OTP = randNum.ToString("D6");
            // storing value in session          
            Session["generatedOTP"] = OTP;

            //mail it to user
            using (MySqlConnection sqlCon = new MySqlConnection(connectionString))
            {
                sqlCon.Open();
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("fetchEmail", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataTable dtdbl = new DataTable();
                sqlDA.Fill(dtdbl);
                string em = dtdbl.Rows[0]["email"].ToString();
                string pass = dtdbl.Rows[0]["password"].ToString();
                sqlCon.Close();
                string fromaddr = em;
                string password = pass;
                MailMessage msg = new MailMessage();
                msg.Subject = "Forgot Password";
                msg.From = new MailAddress(fromaddr);
                msg.Body = "Dear Employee" + "," + "\r\n" + "Your OTP for password reset is" + " " + OTP + "\r\n" + "Regards" + "\r\n" + "PMS";
                msg.To.Add(new MailAddress(fp.emailId));
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.office365.com";
                smtp.Port = 587;
                smtp.UseDefaultCredentials = false;
                smtp.EnableSsl = true;
                NetworkCredential nc = new NetworkCredential(fromaddr, password);
                smtp.Credentials = nc;
                smtp.Send(msg);
            }

            return View("enterOTP");
        
        }
        [HttpPost]
        public ActionResult verifyOTP(forgotPass p)
        {
            string genOTP = Convert.ToString(Session["generatedOTP"]);
            if(genOTP == p.OTP)
            return View("generatePass");
            else
                TempData["msg"] = "<script>alert('Invalid OTP');</script>";
            return View("enterOTP");

        }
        [HttpPost]
        public ActionResult sendNewPass(forgotPass pw)
        {
            string p1 = pw.newPass;
            string p2 = pw.confirmNewPass;
            if(p1==p2)
            {
                //success and reset and redirect to Login
                using (MySqlConnection sqlCon = new MySqlConnection(connectionString))
                {
                    sqlCon.Open();
                    MySqlCommand sqlCmd = new MySqlCommand("newPass", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("eid",Convert.ToInt32(Session["employeeId"]));
                    sqlCmd.Parameters.AddWithValue("npw", pw.newPass);
                    sqlCmd.ExecuteNonQuery();
                    sqlCon.Close();
                    TempData["msg"] = "<script>alert('Password Reset Successfuly');</script>";
                    return RedirectToAction("loginView", "Login");
                }
            }
            else
                TempData["msg"] = "<script>alert('Password and Confirm Pass Doesnt Match');</script>";
            return View("generatePass");
        }
    }
}
﻿using System;
using System.Web.Mvc;
using PMS.Models;
using System.Data;
using MySql.Data.MySqlClient;
using System.Web;
using System.Web.Security;
using System.Web.Helpers;
using System.Collections.Generic;

namespace PMS.Controllers
{
    [Authorize]
    public class DashboardController : Controller
    {

        //string connectionstring = @"Server=leap.chb6nt6repko.ap-southeast-1.rds.amazonaws.com;Database=leap2018;Uid=leap2018;Pwd=leap2018;SslMode=none";
        string connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        // GET: Dashboard
        [HttpGet]
        public ActionResult fetchStatistics()
        {
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
            string name = ticket.Name;
            var cc = new stats();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("fetchCardCounts", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("em", name);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                cc.clientCount = dtbl.Rows[0]["clientCount"].ToString();
                cc.projectCount= dtbl.Rows[0]["projectCount"].ToString();
                cc.mileCount = dtbl.Rows[0]["mileCount"].ToString();
            }
           
            return View("dashboard",cc);
        }
        public ActionResult CharterHelp()

        {
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(authCookie.Value);
            string name = ticket.Name;
            var demo = new List<projectStats>();
            using (MySqlConnection sqlCon = new MySqlConnection(connectionstring))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("populateStats", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("em", name);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                int c = dtbl.Rows.Count;
               
                for (int k = 0; k < c; k++)
                {
                    var ud = new projectStats();
                    ud.categoryname = (dtbl.Rows[k]["categoryname"].ToString());
                    ud.counts = dtbl.Rows[k]["counts"].ToString();
                    demo.Add(ud);
                }
                //cc.proj = demo;
            }
            new Chart(700,300,GetMyCustomTheme())

            .AddTitle("Chart for Project Mapping")

                 .AddSeries("Default",chartType: "bar",
                 markerStep:1,
                  xValue: demo, xField: "categoryname",
                           yValues: demo, yFields: "counts")

                   .Write("bmp");

            return null;
        }
        private string GetMyCustomTheme()
        {
            return @"
            <Chart BackColor=""White"" BackGradientStyle=""TopBottom"" BorderColor=""181, 64, 1"" 
               BorderWidth=""2"" BorderlineDashStyle=""Solid"" Palette=""SemiTransparent"" 
               AntiAliasing=""All"">

               <ChartAreas>
                  <ChartArea Name=""Default"" _Template_=""All"" BackGradientStyle=""None""
                     BackColor=""White"" BackSecondaryColor=""White"" 
                     BorderColor=""64, 64, 64, 64"" BorderDashStyle=""Solid"" 
                     ShadowColor=""Transparent"">                      

                     <AxisX Title=""Project Codes"" IsLabelAutoFit=""True"">
                        <LabelStyle Angle = ""-90"" Interval = ""1"" />   
                     </AxisX>
                     <AxisY Title=""Number Of Employees"" IsLabelAutoFit=""True"">
                        <LabelStyle Angle = ""-90"" Interval = ""1"" />   
                     </AxisY>

                     <Area3DStyle Enable3D=""False"" Inclination=""60"" Rotation=""45""/>
                  </ChartArea>
               </ChartAreas>
            </Chart>";
        }
    }
}
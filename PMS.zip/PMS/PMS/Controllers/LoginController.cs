﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PMS.Models;
using MySql.Data.MySqlClient;
using System.Data;
using System.Web.Security;

namespace PMS.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        //string connectionString = @"Server=leap.chb6nt6repko.ap-southeast-1.rds.amazonaws.com;Database=leap2018;Uid=leap2018;Pwd=leap2018;SslMode=none";
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Dbconnection"].ConnectionString;
        public ActionResult loginView()
        {
            return View("LoginPage");
        }
        [HttpPost]
        public ActionResult loginView(Login log)
        {
            //Session["emailuser"] = log.email;
            
            using (MySqlConnection sqlCon = new MySqlConnection(connectionString))
            {
                sqlCon.Open(); //to open a connection
                MySqlDataAdapter sqlDA = new MySqlDataAdapter("verifyLogin", sqlCon);
                sqlDA.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDA.SelectCommand.Parameters.AddWithValue("uid",log.email );
                sqlDA.SelectCommand.Parameters.AddWithValue("p", log.password);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                sqlCon.Close();
                if(dtbl.Rows[0]["result"].ToString() == "success")
                {
                    FormsAuthenticationTicket FAT = new FormsAuthenticationTicket(1, log.email.Trim(), DateTime.Now, DateTime.Now.AddMinutes(60), false, FormsAuthentication.FormsCookiePath);
                    string encFAT = FormsAuthentication.Encrypt(FAT);
                    Response.Cookies.Add(new HttpCookie(FormsAuthentication.FormsCookiePath, encFAT));
                    FormsAuthentication.RedirectFromLoginPage(log.email.Trim(), true, FormsAuthentication.FormsCookiePath);
                    return RedirectToAction("fetchStatistics", "Dashboard");
                }
                if(dtbl.Rows[0]["result"].ToString() == "invalid")
                {
                    //alert for invalid pass
                    TempData["msg"] = "<script>alert('Invalid Credentials');</script>";
                }
                if(dtbl.Rows[0]["result"].ToString() == "no account")
                {
                    //alert for no account pass
                    TempData["msg"] = "<script>alert('User Not Found');</script>";
                }

            }
            //string s = Convert.ToString(Session["emailuser"]);
            return View("LoginPage");
        }
    }
}